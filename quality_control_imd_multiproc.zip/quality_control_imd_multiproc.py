#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 17 10:26:26 2020

@author: sambit
"""
import datetime as dt
from osgeo import osr
#import cartopy.crs as ccrs
import os
import scipy as sp
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import wradlib as wrl
import warnings
import re
import multiprocessing
from pathlib2 import Path
warnings.filterwarnings('ignore')

location = os.getcwd()
basepath = os.path.dirname(location)
rawfiles_loc = basepath + "/INPUT_DATA"
dirpath1 = basepath + "/VEL"
dirpath2 = basepath + "/VEL/long_range"
dirpath3 = basepath + "/VEL/short_range"
dirpath4 = basepath + "/DBZ"
dirpath5 = basepath + "/DBZ/long_range"
dirpath6 = basepath + "/DBZ/short_range"


Path(dirpath2).mkdir(parents=True,exist_ok=True)
Path(dirpath3).mkdir(parents=True,exist_ok=True)
Path(dirpath4).mkdir(parents=True,exist_ok=True)
Path(dirpath5).mkdir(parents=True,exist_ok=True)
Path(dirpath6).mkdir(parents=True,exist_ok=True)



#if not os.path.exists(dirpath1):
#    os.makedirs(dirpath1)
#    os.makedirs(dirpath2)
#    os.makedirs(dirpath3)
#    os.makedirs(dirpath4)
#    os.makedirs(dirpath5)
#    os.makedirs(dirpath6)
#    os.makedirs(dirpath7)
#    os.makedirs(dirpath8)
#    
counter = 0
ncfiles = []

def tryint(s):
    try:
        return int(s)
    except:
        return s

def alphanum_key(s):
    return [tryint(c) for c in re.split('([0-9]+)',s)]

def sort_nicely(l):
     l.sort(key=alphanum_key)

for file in os.listdir(rawfiles_loc):
    try:
        if file.endswith(".nc"):
            #print "txt file found:\t", file
            ncfiles.append(str(file))
            counter = counter+1
    except Exception as e:
        raise e
        print("No files found here!")

sortedfiles = sorted(ncfiles)

sort_nicely(sortedfiles)
#elevation = 0.5
#proj = osr.SpatialReference()
#proj.ImportFromEPSG(32632)
#a1 = 6378137.000        ##semi-major axis of Earth ellipsoid in m
#b1 = 6356752.314        ##semi-minor axis of Earth ellipsoid in m
#e1 = 0.0818191908426    ##first eccentricity of Earth ellipsoid
#h0 = 100         ##altitude of the radar site in m
#ke=1.333        ### atmospheric refractivity term
num = 0
num1= 0
alpha = 0.8
beta = 0.3
vel = None
dbZ = None
sigma = None
zdr = None
phidp = None
rhohv = None

## Functions for clutter mitigation ##
## If only DBZ is availaible ##
def gabella_filter(rawdbz):
    ######################## for clutter mitigation ################ 
    clutter = wrl.clutter.filter_gabella(rawdbz,wsize=5,thrsnorain=0.0,tr1=10.0,n_p=8,tr2=1.3)
    mdata = rawdbz.copy()
    mdata = np.ma.array(mdata,mask=clutter)
    mdata[mdata.mask] = np.nan
    
    return mdata

## If all base and polarimetric variables are availaible ## 
def polarimetric_filter(rawdbz,rhohv,phidp,velocity,zdr,clutter=None):
    if clutter == None:
        clutter = wrl.clutter.filter_gabella(rawdbz,wsize=5,thrsnorain=0.0,tr1=10.0,n_p=8,tr2=1.3)
    else:
        clutter == clutter
    mdata = rawdbz.copy()
    mdata = np.ma.array(mdata,mask=clutter)
    mdata[mdata.mask] = np.nan
    
    dat = {}
    dat["rho"] = rhohv
    dat["phi"] = phidp
    dat["ref"] = mdata
    dat["dop"] = velocity
    dat["zdr"] = zdr
    dat["map"] = clutter
    weights = {"zdr":0.5,"rho":0.5,"rho2":0.3,"phi":0.3,"dop":0.3,"map":0.5}
    cmap,nanmask = wrl.clutter.classify_echo_fuzzy(dat,weights=weights,thresh=0.5)
    rdata = np.ma.array(mdata.copy(),mask=cmap)
    rdata[rdata.mask] = np.nan
    rdata = wrl.dp.linear_despeckle(rdata,5)
    
    return rdata

def process_raw_file(filename):
    raw = wrl.io.read_generic_netcdf('%s/%s' %(rawfiles_loc,filename))
    print("Processing File: %s" %(filename))
    
    #### CHECK WHETHER SINGLE-POL OR DUAL-POL DWR ####
    if ('ZDR' in raw['variables'].keys() and 'RHOHV' in raw['variables'].keys() and 'PHIDP' in raw['variables'].keys()):
        zdr = raw['variables']['ZDR']['data'] 
        phidp = raw['variables']['PHIDP']['data']
        rhohv = raw['variables']['RHOHV']['data']
        if (zdr.size !=0) and (phidp.size !=0) and (rhohv.size !=0): 
            pol_type = 'dual_pol'
        else:
            pol_type = 'single_pol'
    else:
        pol_type = 'single_pol'
    
    time1 = filename[16:30]
    basename = filename[11:16] + time1
    site_lat = raw['variables']['siteLat']['data']
    site_lon = raw['variables']['siteLon']['data']
    site_alt = raw['variables']['siteAlt']['data']
    radar_location = [site_lon.item(),site_lat.item(),site_alt.item()]
    num_elev = raw['dimensions']['sweep']['size']
    range_resol = raw['variables']['gateSize']['data']
    num_bins = raw['dimensions']['bin']['size']
    if num_elev <= 3:
#        num = num+1
        mode = "long_range"
    if num_elev == 10:
#        num1 = num1+1
        mode = "short_range"
    
    if mode == "short_range":    
        fgate = raw['variables']['firstGateRange']['data']
        h_range = np.arange(0.0,range_resol*num_bins,range_resol)
        max_range = raw['variables']['unambigRange']['data'] ##maximum unambiguous range 
        num_azim = raw['dimensions']['radial']['size']
        az = raw['variables']['radialAzim']['data']
        elevation_array = raw['variables']['radialElev']['data']
        elevation_list = raw['variables']['elevationList']['data']
        elev = raw['variables']['elevationAngle']['data']
        polargrid = np.meshgrid(h_range,az)
        v_n = raw['variables']['nyquist']['data'] # nyquist velocity
        sweep = raw['variables']['elevationNumber']['data']
    #### can be used when nyquist value is not known #### 
    #    opfreq = 5.625
    #    prf_h = 600
    #    lam = (3*pow(10,8))/(opfreq*pow(10,9))
    #    v_n = prf_h*lam/4.0
    
    #    initial_radial = np.empty((num_elev))
        initial_radial = -999 
    #    
    ####################using WRADLIB libraries###############
        if pol_type == 'dual_pol':   
            if ('V' in raw['variables'].keys()):
                vel = raw['variables']['V']['data']
                fill_value = raw['variables']['V']['_FillValue']
            if ('Z' in raw['variables'].keys()):    
                dbZ = raw['variables']['Z']['data']
            if ('W' in raw['variables'].keys()):    
                sigma = raw['variables']['W']['data']
            if ('ZDR' in raw['variables'].keys()):    
                zdr = raw['variables']['ZDR']['data']
            if ('PHIDP' in raw['variables'].keys()):    
                phidp = raw['variables']['PHIDP']['data']
            if ('RHOHV' in raw['variables'].keys()):    
                rhohv = raw['variables']['RHOHV']['data']
            
        if pol_type ==  'single_pol':
            ### base variables ###
            if ('V' in raw['variables'].keys()):
                vel = raw['variables']['V']['data']
                fill_value = raw['variables']['V']['_FillValue']
            if ('Z' in raw['variables'].keys()):    
                dbZ = raw['variables']['Z']['data']
            if ('W' in raw['variables'].keys()):    
                sigma = raw['variables']['W']['data']
            
        if dbZ is not None and dbZ.size != 0 and num_azim == 360:
            if pol_type == "single_pol":
                ### call the gabella-filter function for decluttering ###
                rdata = gabella_filter(dbZ)
                np.savetxt('%s/%s/%s_%s_corr_dbz_sweep_%02d.txt' %(dirpath4,mode,mode,basename,sweep), rdata)
            if pol_type == "dual_pol":
                ### Call the polarimetric_filter function for decluttering ###
                rdata = polarimetric_filter(dbZ,rhohv,phidp,vel,zdr)
                np.savetxt('%s/%s/%s_%s_corr_dbz_sweep_%02d.txt' %(dirpath4,mode,mode,basename,sweep), rdata)
        else: ## If num_azim for the sweep is not equal to 360
            rdata = np.ones((360,num_bins)) * np.nan
            np.savetxt('%s/%s/%s_%s_corr_dbz_sweep_%02d.txt' %(dirpath4,mode,mode,basename,sweep), rdata)
        
        if vel is not None and vel.size != 0 and num_azim == 360: 
            
            if dbZ is not None and dbZ.size != 0:
                ## remove clutter marked pixels/bins ##
                vel[np.where(np.isnan(rdata))] = np.nan
            vel[np.where(vel==fill_value)] = np.nan
        
            initial_gate1 = -999
            initial_gate2 = -999
            v_c = np.empty((num_elev,num_azim,num_bins))
            
            if mode == 'short_range':
                
                lim=40
                search = 0
        #        a_min = 360*e
        #        a_max = 360*(e+1)
                velocity = vel
#                refl = dbZ
                radial_flag = np.ones((num_azim))
                N1 = np.zeros(num_azim)
                v_m1 = np.empty(num_azim)
        #        gate_num = []
                good_radial_vel = []
                ng = 0
                n0 = np.zeros((num_azim))
                #while initial_radial[e] == -999:
                for a in range(num_azim):
                    gate_value = []
                    azim_value = []
                    r = 0
                    while r<num_bins:
                          if np.isfinite(velocity[a,r]): #!= fill_value:
                             gate = "non_missing"
                             n0[a] = n0[a]+1
                             gate_value.append(velocity[a,r])
                             
                          else:
                              gate = "missing"
                              m=0
                              while m<len(gate_value)-1:
                                   shear = abs(gate_value[m+1] - gate_value[m])
                                   if shear > (alpha*v_n):
                                      radial_flag[a] = 0.0
                                   m = m+1
                              gate_value = []
                          
                          r = r+1    
                          
                index = 0             
                while index<num_azim:
                      good_radial_vel = []
                      if radial_flag[index] == 1.0:
                         ng = ng+1
                         #initial_radial[e] = index
                         x=0
                         while x < num_bins:
                              if np.isfinite(velocity[index,x]): #!= fill_value:
                                 if abs(velocity[index,x]) < (beta*v_n):
                                    good_radial_vel.append(velocity[index,x])
                                    N1[index] = N1[index]+1
                              x = x+1     
                         v_m1[index] = np.mean(good_radial_vel)
                         #v_ref[e] = v_m1[index]
                      index = index+1
                if ng > 1:
                   for l in range(num_azim-3):
                       if radial_flag[l] == 1.0:
                          if v_m1[l] >=0 and v_m1[l+1] >= 0:
                             if v_m1[l+2] < 0 and v_m1[l+3] <0: 
                                if N1[l+1] > N1[l+2]:
                                   initial_radial = l+1
                                   v_ref = v_m1[l+1]
                                else:
                                    initial_radial = l+2
                                    v_ref = v_m1[l+2]
                   
                          if v_m1[l] < 0 and v_m1[l+1] < 0:
                             if v_m1[l+2] >= 0 and v_m1[l+3] >= 0: 
                                if N1[l+1] > N1[l+2]:
                                   initial_radial = l+1
                                   v_ref = v_m1[l+1]
                                else:
                                    initial_radial = l+2
                                    v_ref = v_m1[l+2]
        #        else: 
        #                if ng == 1:
        #                   for pos in range(num_azim):
        #                       if radial_flag[pos] == 1.0:
        #                          initial_radial[e] = pos 
                if initial_radial != -999:
                      print("Initial radial for elevation %s found in search %s" %(np.round(elev,1),search))
                else:
                   search = search + 1
                   print("No initial radial found for elevation angle %s in first search!!!" %(np.round(elev,1)))
                   print("Trying second round search!!")
                   while lim >=5:
                         N0 = np.zeros((num_azim))
                         v_m0 = np.empty(num_azim)
                         rad_flag_0 = np.ones((num_azim))
                         good_rad_vel0 = []
                         ng_0 = 0
                         nn0 = np.zeros((num_azim))
                         for a in range(num_azim):
                             gate_value_0 = []
                             azim_value_0 = []
                             r = 0
                             while r<num_bins:
                                   if np.isfinite(velocity[a,r]): #!= fill_value:
                                      gate = "non_missing"
                                      nn0[a] = nn0[a]+1
                                      gate_value_0.append(velocity[a,r])
                                      r = r+1
                                   else:
                                       gate = "missing"
                                       if nn0[a] >= lim:
                                          m=0
                                          while m<len(gate_value)-1:
                                                shear = abs(gate_value_0[m+1] - gate_value_0[m])
                                                if shear > (alpha*v_n):
                                                   rad_flag_0[a] = 0.0
                                                m = m+1
                                       gate_value = []
                                       r = r+1   
                                 
                         index = 0    
                         while index < num_azim:
                             if rad_flag_0[index] == 1.0:
                                x=0 
                                while x < num_bins:
                                      if np.isfinite(abs(velocity[index,x])): #!= fill_value:
                                         good_rad_vel0.append(velocity[index,x])
                                         N0[index] = N0[index]+1
                                      x = x+1     
                             v_m0[index] = np.mean(good_rad_vel0)
                             if v_m0[index] < (beta*v_n):
                                ng_0 = ng_0+1
                                initial_radial = index
                                v_ref = v_m0[index]
                             index = index+1
                    
                         if ng_0 > 1:
                            min_vm0 = v_m0[initial_radial]
                            for pos in range(num_azim):
                                if rad_flag_0[pos] == 1.0:
                                   if v_m0[pos] < min_vm0:
                                      min_vm0 = v_m0[pos]
                                      initial_radial = pos
                                      v_ref = v_m0[pos]
                         if initial_radial != -999:
                            print("Initial radial for elevation %s found in search %s" %(np.round(elev,1),search))
                            lim = 0
                         else:
                             lim = lim-5
                
                if initial_radial == -999:
                    print("Initial radial could not be found, no dealiasing to be performed for elevation angle %s !" %(np.round(elev,1)))
            ################################################  
        ##############for initial radial dealiasing###############
                k0_list = []
                k1_list = []
                k2_list = []
                gate_flag = np.zeros((num_azim,num_bins))
                corr_vel = np.empty((num_azim,num_bins))
                corr_vel[:] = velocity[:]
                #corr_vel = np.ma.masked_invalid(corr_vel)
                #corr_vel = np.ma.masked_equal(corr_vel,fill_value)
                if initial_radial != -999:
                   if initial_radial == 359:
                       loc = initial_radial
                       loc1 = initial_radial-1
                       loc2 = 0
                   else:
                       loc = initial_radial
                       loc1 = initial_radial-1
                       loc2 = initial_radial+1
                   r=0                         
                   while r < num_bins:
                         if np.isfinite(velocity[loc,r]): #!= fill_value:
                            k0 = np.rint((v_ref - velocity[loc,r])/(2*v_n))
                            k0_list.append(k0)
                            corr_vel[loc,r] = velocity[loc,r] + k0*2*v_n 
                            gate_flag[loc,r] = 1
                         r = r+1            
                   ###########for neighbouring radials in azimuth direction##########
                   r=0
                   while r < num_bins:
                       if np.isfinite(corr_vel[loc,r]) and np.isfinite(velocity[loc,r]): #!= fill_value:
                          if np.isfinite(velocity[loc1,r]): #!= fill_value:
                             k1 = np.rint((corr_vel[loc,r] - velocity[loc1,r])/(2*v_n))
                             k1_list.append(k1)
                             corr_vel[loc1,r] = velocity[loc1,r] + k1*2*v_n 
                             gate_flag[loc1,r] = 1
                          else:
                              gate_flag[loc1,r] = 0
                          
                          if np.isfinite(velocity[loc2,r]): #!= fill_value:
                             k2 = np.rint((corr_vel[loc,r] - velocity[loc2,r])/(2*v_n))
                             k2_list.append(k2)
                             corr_vel[loc2,r] = velocity[loc2,r] + k2*2*v_n 
                             gate_flag[loc2,r] = 1
                          else:
                              gate_flag[loc2,r] = 0
                       else:
                            gate_flag[loc1,r] = 0
                            gate_flag[loc2,r] = 0
                       r = r+1              
                
        ######################First round radial by radial dealisaing#####################
        ####################for clockwise dealiasing#########################
                   for theta in range(int(loc2+1),int(loc2+1+180)):
                       k_cw_list = []
                       if theta >= 359:
                          theta = theta - 359
                         
                          #good_vel_acw = []
                       #################In azimuth direction##############
                       for r in range(0,num_bins):
                           good_vel_cw = []
                           if np.isfinite(velocity[theta,r]): #!= fill_value:
                               for p in range(theta-1,theta-4,-1):
                                   if np.isfinite(corr_vel[p,r]) and gate_flag[p,r] == 1:
                                       good_vel_cw.append(corr_vel[p,r])
                               v_r = np.mean(good_vel_cw)
                               if len(good_vel_cw) == 3 and np.isfinite(v_r): #!= np.nan:
                                  if abs(good_vel_cw[1] - good_vel_cw[0]) < alpha*v_n or abs(good_vel_cw[2] - good_vel_cw[1]) < alpha*v_n:
                                     if abs(velocity[theta,r] - v_r) < alpha*v_n:
                                        status = "good"
                                        k_cw = np.rint((v_r - velocity[theta,r])/(2*v_n))
                                        k_cw_list.append(k_cw)
                                        if (np.isfinite(k_cw)):
                                            corr_vel[theta,r] = velocity[theta,r] + k_cw*2*v_n
                                            gate_flag[theta,r] = 1
                                                  
                       ##################In radial direction#################
                   for theta in range(int(loc2+1),int(loc2+1+180)):  
                       if theta >= 359:
                          theta = theta - 359
                       jump = int(np.rint(10000/range_resol))##for 20 km span##
                       bin_num = jump
                       bin_min = bin_num - jump
                       bin_max = bin_num + jump            
                       cont_vel1 = []
                       cont_bin1 = []
                       #cont_vel2 = []
                       v1 = []
                       v2 = []
                       v3 = []
                       v4 = []
                       temp = []
                       enum1=1
                       enum2=1
                       c = 1
                       gt = []
                       for j in range(1,int(num_bins/jump)):
                           bin_num = jump*j
                           bin_min = bin_num - jump
                           bin_max = bin_num + jump
                           cont_vel1 = []
                           cont_bin1 = []
                           
                           for x in range(bin_min,bin_max):    
                           #if x>=bin_min and x <= bin_max:
                               #if gate_flag[theta,x] == 1.0:
                               if np.isfinite(corr_vel[theta,x]): #!= fill_value:
                                  cont_vel1.append(corr_vel[theta,x])
                                  cont_bin1.append(x)
                                  enum1 = enum1+1
                                  flag1 = "contiguous"                             
                               else:                          
                                    if enum1 >= jump:
                                      for v in range(2,len(cont_vel1)-2):
                                          for g in range(v-2,v+2):
                                              if gate_flag[theta,v] == 1:                           
                                                 if gate_flag[theta,g] == 1 and gate_flag[theta,g-1] == 1:
                                                    if abs(cont_vel1[g] - cont_vel1[g-1]) < alpha*v_n:
                                                       vel_flag1 = "no_shear"
                                                       if gate_flag[theta-1,v] == 1 and gate_flag[theta-2,v] == 1 and gate_flag[theta-3,v] == 1: 
                                                           if (corr_vel[theta-1,v] - corr_vel[theta-2,v]) < alpha*v_n and (corr_vel[theta-2,v] - corr_vel[theta-3,v]) < alpha*v_n: 
                                                               initial_gate1 = cont_bin1[v]
                                                               enum1 = 1
                                                    else:
                                                        vel_flag1 = "shear"
                                                        enum1 = 1
                                    flag1 = "non-contiguous"                    
                                   
           
                               
                       if initial_gate1 != -999:               ###########check this#######
                           for pos1 in range(int(initial_gate1)+1,num_bins):
                               k_un_list1 = []
                               if gate_flag[theta,pos1] == 0 and np.isfinite(corr_vel[theta,pos1]): #!= fill_value:
                                  v1.append(corr_vel[theta,pos1])
                                  #temp.append(pos1)
                                  gc = 1
                                  gv = []
                                  rb = pos1-1
                                  while gc <=3 and rb >= int(initial_gate1)-2:
                                        if gate_flag[theta,rb] == 1:
                                           gv.append(corr_vel[theta,rb])
                                           gc = gc+1
                                        rb = rb-1
                                  k_un = np.rint((np.average(gv) - corr_vel[theta,pos1])/(2*v_n))
                                  k_un_list1.append(k_un)
                                  if (np.isfinite(k_un)):
                                      corr_vel[theta,pos1] = corr_vel[theta,pos1] + k_un*2*v_n
                                      gate_flag[theta,pos1] = 1
                              #v2.append(corr_vel[loc1,pos1])     
                           for pos1 in range(int(initial_gate1-1),2,-1):
                               k_un_list2 = []
                               if gate_flag[theta,pos1] == 0 and np.isfinite(corr_vel[theta,pos1]): #!= fill_value:
                                  v2.append(corr_vel[theta,pos1])
                              #temp.append(pos1)
                                  gc = 1
                                  gv = []
                                  rb = pos1+1
                                  while gc <=3 and rb <= int(initial_gate1)+2:
                                        if gate_flag[theta,rb] == 1:
                                           gv.append(corr_vel[theta,rb])
                                           gc = gc+1
                                        rb = rb+1
                                  k_un = np.rint((np.average(gv) - corr_vel[theta,pos1])/(2*v_n))
                                  k_un_list2 = []
                                  if (np.isfinite(k_un)):
                                      corr_vel[theta,pos1] = corr_vel[theta,pos1] + k_un*2*v_n
                                      gate_flag[theta,pos1] = 1  
                       
        ###################for anti-clockwise dealiasing##################            
                   for theta in range(int(loc1-1),int(loc1-1-180),-1):
                       k_acw_list = []
                       if theta <= 0:
                          theta = 359 + theta
                       
                       #################In azimuth direction##############
                       for r in range(0,num_bins):
                           good_vel_acw = []  
                           if np.isfinite(velocity[theta,r]): #!= fill_value:
                              for p in range(theta-1,theta-4,-1):
                                  if corr_vel[p,r] != fill_value and gate_flag[p,r] == 1:
                                     good_vel_acw.append(corr_vel[p,r])
                              v_r = np.average(good_vel_acw)
                              if len(good_vel_acw) == 3 and np.isfinite(v_r): #!= np.nan:
                                 if abs(good_vel_acw[1] - good_vel_acw[0]) < alpha*v_n or abs(good_vel_acw[2] - good_vel_acw[1]) < alpha*v_n:
                                    if abs(velocity[theta,r] - v_r) < alpha*v_n:
                                        status1 = "good"
                                        k_acw = np.rint((v_r - velocity[theta,r])/(2*v_n))
                                        k_acw_list.append(k_acw)
                                        if (np.isfinite(k_acw)):
                                            corr_vel[theta,r] = velocity[theta,r] + k_acw*2*v_n
                                            gate_flag[theta,r] = 1
                       ################In radial direction################
                   for theta in range(int(loc1-1),int(loc1-1-180),-1):  
                       if theta <= 0:
                          theta = 359 + theta
                       jump = int(np.rint(10000/range_resol))##for 20 km span##
                       bin_num = jump
                       bin_min = bin_num - jump
                       bin_max = bin_num + jump
                       cont_vel2 = []
                       cont_bin2 = []
                       #v1 = []
                       #v2 = []
                       v3 = []
                       v4 = []
                       temp = []
                            #enum1=1
                       enum2=1
                       c = 1
                       gt = []
                       for j in range(1,int(num_bins/jump)):
                           bin_num = jump*j
                           bin_min = bin_num - jump
                           bin_max = bin_num + jump
                           cont_vel2 = []
                           cont_bin2 = []
                           
                           for x in range(bin_min,bin_max):    
                           #if x>=bin_min and x <= bin_max:
                               #if gate_flag[theta,x] == 1.0:
                               if np.isfinite(corr_vel[theta,x]): #!= fill_value:
                                  cont_vel2.append(corr_vel[theta,x])
                                  cont_bin2.append(x)
                                  enum2 = enum2+1
                                  flag2 = "contiguous"                             
                               else:
                                    if enum2 >= jump:
                                      for v in range(2,len(cont_vel2)-2):
                                          for g in range(v-2,v+2):
                                              if gate_flag[theta,v] == 1:                           
                                                 if gate_flag[theta,g] == 1 and gate_flag[theta,g-1] == 1:
                                                    if abs(cont_vel2[g] - cont_vel2[g-1]) < alpha*v_n:
                                                       vel_flag2 = "no_shear"
                                                       if gate_flag[theta-1,v] == 1 and gate_flag[theta-2,v] == 1 and gate_flag[theta-3,v] == 1: 
                                                           if (corr_vel[theta-1,v] - corr_vel[theta-2,v]) < alpha*v_n and (corr_vel[theta-2,v] - corr_vel[theta-3,v]) < alpha*v_n: 
                                                               initial_gate2 = cont_bin2[v]
                                                               enum2 = 1
                                                    else:
                                                        vel_flag2 = "shear"
                                                        enum2 = 1
                                    flag2 = "non-contiguous"
                                    
                               
                       if initial_gate2 != -999:
                           for pos2 in range(int(initial_gate2)+1,num_bins):
                               k_un_list3 = []
                               if gate_flag[theta,pos2] == 0 and np.isfinite(corr_vel[theta,pos2]): #!= fill_value:
                                  v3.append(corr_vel[theta,pos2])
                                  #temp.append(pos1)
                                  gc = 1
                                  gv = []
                                  rb = pos2-1
                                  while gc <=3 and rb >= int(initial_gate2)-2:
                                        if gate_flag[theta,rb] == 1:
                                           gv.append(corr_vel[theta,rb])
                                           gc = gc+1
                                        rb = rb-1
                                  k_un = np.rint((np.average(gv) - corr_vel[theta,pos2])/(2*v_n))
                                  k_un_list3.append(k_un)
                                  if (np.isfinite(k_un)):
                                      corr_vel[theta,pos2] = corr_vel[theta,pos2] + k_un*2*v_n
                                      gate_flag[theta,pos2] = 1
                              #v2.append(corr_vel[loc1,pos1])     
                           for pos2 in range(int(initial_gate2-1),2,-1):
                               k_un_list4 = []
                               if gate_flag[theta,pos2] == 0 and np.isfinite(corr_vel[theta,pos2]): #!= fill_value:
                                  v4.append(corr_vel[theta,pos2])
                              #temp.append(pos1)
                                  gc = 1
                                  gv = []
                                  rb = pos1+1
                                  while gc <=3 and rb <= int(initial_gate2)+2:
                                        if gate_flag[theta,rb] == 1:
                                           gv.append(corr_vel[theta,rb])
                                           gc = gc+1
                                        rb = rb+1
                                  k_un = np.rint((np.average(gv) - corr_vel[theta,pos2])/(2*v_n))
                                  k_un_list4.append(k_un)
                                  if (np.isfinite(k_un)):
                                      corr_vel[theta,pos2] = corr_vel[theta,pos2] + k_un*2*v_n
                                      gate_flag[theta,pos2] = 1 
        
        ##############################################End of First round dealiasing###########################
                
        #############################################Second Round Dealiasing##################################
        ####################for clockwise dealiasing#########################
                   for theta in range(int(loc2+1),int(loc2+1+180)):
                       if theta >= 359:
                          theta = theta - 359
                          
                       r=0
                       #################In azimuth direction##############
                       while r < num_bins:
                           good_vel_cw = []
                           if np.isfinite(velocity[theta,r]) and gate_flag[theta,r] == 0:
                               M = 3
                               sa = theta - 1
                               ea = sa - 3
                               rounds=0
                               while rounds <= M:
                                     #print ea," ",r
                                     for p in range(sa,ea,-1):
                                         if np.isfinite(corr_vel[p,r]) and gate_flag[p,r] == 1:
                                            good_vel_cw.append(corr_vel[p,r])
                                     v_r = np.average(good_vel_cw)
                                     if len(good_vel_cw) == 3 and np.isfinite(v_r): #!= np.nan:
                                        if abs(good_vel_cw[1] - good_vel_cw[0]) < alpha*v_n and abs(good_vel_cw[2] - good_vel_cw[1]) < alpha*v_n:
                                           if abs(velocity[theta,r] - v_r) < alpha*v_n:
                                              status = "good"
                                              rounds = 4
                                              
                                              k_cw = np.rint((v_r - velocity[theta,r])/(2*v_n))
                                              if (np.isfinite(k_cw)):
                                                  corr_vel[theta,r] = velocity[theta,r] + k_cw*2*v_n
                                                  gate_flag[theta,r] = 1
                                        
                                        else:                                    
                                            sa = sa - 1
                                            ea = sa - 3
                                     rounds = rounds+1     
                           r = r+1              
                       ##################In radial direction#################
                   for theta in range(int(loc2+1),int(loc2+1+180)):    
                       if theta >= 359:
                          theta = theta - 359
                       jump = int(np.rint(10000/range_resol))##for 20 km span##
                       bin_num = jump
                       bin_min = bin_num - jump
                       bin_max = bin_num + jump
                       cont_vel1 = []
                       cont_bin1 = []
                       #cont_vel2 = []
                       v1 = []
                       v2 = []
                       v3 = []
                       v4 = []
                       temp = []
                       enum1=1
                       enum2=1
                       c = 1
                       gt = []
                       for j in range(1,int(num_bins/jump)):
                           bin_num = jump*j
                           bin_min = bin_num - jump
                           bin_max = bin_num + jump
                           cont_vel1 = []
                           cont_bin1 = []
                           enum1 = 1
                           for x in range(bin_min,bin_max):    
                           #if x>=bin_min and x <= bin_max:
                               #if gate_flag[theta,x] == 1.0:
                               if np.isfinite(corr_vel[theta,x]): #!= fill_value:
                                  cont_vel1.append(corr_vel[theta,x])
                                  cont_bin1.append(x)
                                  enum1 = enum1+1
                                  flag1 = "contiguous"                             
                               else:
                                    flag1 = "non-contiguous"
                                    exit
                                 #enum1 = 1
                                 #exit
        
        #                   if enum1 > step/2:
                           if flag1 == "contiguous" and enum1 >= jump:
                           #gt.append(enum1)
                              for v in range(2,len(cont_vel1)-2):
                                  for g in range(v-2,v+2):
                                      if gate_flag[theta,v] == 1:                           
                                         if gate_flag[theta,g] == 1 and gate_flag[theta,g-1] == 1:
                                            if abs(cont_vel1[g] - cont_vel1[g-1]) < alpha*v_n:
                                               vel_flag1 = "no_shear"
                                               if gate_flag[theta-1,v] == 1 and gate_flag[theta-2,v] == 1 and gate_flag[theta-3,v] == 1: 
                                                   if (corr_vel[theta-1,v] - corr_vel[theta-2,v]) < alpha*v_n and (corr_vel[theta-2,v] - corr_vel[theta-3,v]) < alpha*v_n: 
                                                       initial_gate1 = cont_bin1[v]
                                            else:
                                                vel_flag1 = "shear"
                                     
                       if initial_gate1 != -999:
                           for pos1 in range(int(initial_gate1)+1,num_bins):
                               if gate_flag[theta,pos1] == 0 and np.isfinite(corr_vel[theta,pos1]): #!= fill_value:
                                  v1.append(corr_vel[theta,pos1])
                                  #temp.append(pos1)
                                  gc = 1
                                  gv = []
                                  rb = pos1-1
                                  while gc <=3 and rb >= int(initial_gate1)-2:
                                        if gate_flag[theta,rb] == 1:
                                           gv.append(corr_vel[theta,rb])
                                           gc = gc+1
                                        rb = rb-1
                                  
                                  k_un = np.rint((np.average(gv) - corr_vel[theta,pos1])/(2*v_n))
                                  if (np.isfinite(k_un)):
                                      corr_vel[theta,pos1] = corr_vel[theta,pos1] + k_un*2*v_n
                                      gate_flag[theta,pos1] = 1
                              #v2.append(corr_vel[loc1,pos1])     
                           for pos1 in range(int(initial_gate1-1),2,-1):
                               if gate_flag[theta,pos1] == 0 and np.isfinite(corr_vel[theta,pos1]): #!= fill_value:
                                  v2.append(corr_vel[theta,pos1])
                              #temp.append(pos1)
                                  gc = 1
                                  gv = []
                                  rb = pos1+1
                                  while gc <=3 and rb <= int(initial_gate1)+2:
                                        if gate_flag[theta,rb] == 1:
                                           gv.append(corr_vel[theta,rb])
                                           gc = gc+1
                                        rb = rb+1
                                  
                                  k_un = np.rint((np.average(gv) - corr_vel[theta,pos1])/(2*v_n))
                                  if (np.isfinite(k_un)):
                                      corr_vel[theta,pos1] = corr_vel[theta,pos1] + k_un*2*v_n
                                      gate_flag[theta,pos1] = 1  
                       
        ###################for anti-clockwise dealiasing##################            
                   for theta in range(int(loc1-1),int(loc1-1-180),-1):
                       if theta < 0:
                          theta = 359 + theta
                       r=0 
                       #################In azimuth direction##############
                       while r < num_bins:
                           good_vel_acw = [] 
                           if np.isfinite(velocity[theta,r]) and gate_flag[theta,r] == 0:
                               M = 3
                               sa = theta - 1
                               ea = sa - 3
                               rounds = 0
                               while rounds<=M:
                                   
                                     for p in range(sa,ea,-1):
                                         if np.isfinite(corr_vel[p,r]) and gate_flag[p,r] == 1:
                                            good_vel_acw.append(corr_vel[p,r])
                                     v_r = np.average(good_vel_acw)
                                     if len(good_vel_acw) == 3 and np.isfinite(v_r): #!= np.nan:
                                        if abs(good_vel_acw[1] - good_vel_acw[0]) < alpha*v_n and abs(good_vel_acw[2] - good_vel_acw[1]) < alpha*v_n:
                                           if abs(velocity[theta,r] - v_r) < alpha*v_n:
                                              status1 = "good"
                                              rounds = 4
                                              
                                              k_acw = np.rint((v_r - velocity[theta,r])/(2*v_n))
                                              if (np.isfinite(k_acw)):
                                                  corr_vel[theta,r] = velocity[theta,r] + k_acw*2*v_n
                                                  gate_flag[theta,r] = 1
                                     #if status1 == "good":
                                           else:                    
                                               sa = sa - 1
                                               ea = sa - 3
                                     
                                     rounds = rounds+1     
                           r = r+1              
                       ################In radial direction################
                   for theta in range(int(loc1-1),int(loc1-1-180),-1): 
                       if theta < 0:
                          theta = 359 + theta
                       jump = int(np.rint(10000/range_resol))##for 20 km span##
                       bin_num = jump
                       bin_min = bin_num - jump
                       bin_max = bin_num + jump
                       cont_vel2 = []
                       cont_bin2 = []
                       #v1 = []
                       #v2 = []
                       v3 = []
                       v4 = []
                       temp = []
                            #enum1=1
                       enum2=1
                       c = 1
                       gt = []
                       for j in range(1,int(num_bins/jump)):
                           bin_num = jump*j
                           bin_min = bin_num - jump
                           bin_max = bin_num + jump
                           cont_vel2 = []
                           cont_bin2 = []
                           enum2 = 1
                           for x in range(bin_min,bin_max):    
                           #if x>=bin_min and x <= bin_max:
                               #if gate_flag[theta,x] == 1.0:
                               if np.isfinite(corr_vel[theta,x]): #!= fill_value:
                                  cont_vel2.append(corr_vel[theta,x])
                                  cont_bin2.append(x)
                                  enum2 = enum2+1
                                  flag2 = "contiguous"                             
                               else:
                                    flag2 = "non-contiguous"
                                    exit
                                 #enum1 = 1
                                 #exit
        
        #                   if enum1 > step/2:
                           if flag2 == "contiguous" and enum2 >= jump/2:
                           #gt.append(enum1)
                              for v in range(2,len(cont_vel2)-2):
                                  for g in range(v-2,v+2):
                                      if gate_flag[theta,v] == 1:                           
                                         if gate_flag[theta,g] == 1 and gate_flag[theta,g-1] == 1:
                                            if abs(cont_vel2[g] - cont_vel2[g-1]) < alpha*v_n:
                                               vel_flag2 = "no_shear"
                                               if gate_flag[theta-1,v] == 1 and gate_flag[theta-2,v] == 1 and gate_flag[theta-3,v] == 1: 
                                                   if (corr_vel[theta-1,v] - corr_vel[theta-2,v]) < alpha*v_n and (corr_vel[theta-2,v] - corr_vel[theta-3,v]) < alpha*v_n: 
                                                       initial_gate2 = cont_bin2[v]
                                            else:
                                                vel_flag2 = "shear"
        
                       if initial_gate2 != -999:
                           for pos2 in range(int(initial_gate2)+1,num_bins):
                               if gate_flag[theta,pos2] == 0 and np.isfinite(corr_vel[theta,pos2]): #!= fill_value:
                                  v3.append(corr_vel[theta,pos2])
                                  #temp.append(pos1)
                                  gc = 1
                                  gv = []
                                  rb = pos2-1
                                  while gc <=3 and rb >= int(initial_gate2)-2:
                                        if gate_flag[theta,rb] == 1:
                                           gv.append(corr_vel[theta,rb])
                                           gc = gc+1
                                        rb = rb-1
                                  
                                  k_un = np.rint((np.average(gv) - corr_vel[theta,pos2])/(2*v_n))
                                  if (np.isfinite(k_un)):
                                      corr_vel[theta,pos2] = corr_vel[theta,pos2] + k_un*2*v_n
                                      gate_flag[theta,pos2] = 1
                              #v2.append(corr_vel[loc1,pos1])     
                           for pos2 in range(int(initial_gate2-1),2,-1):
                               if gate_flag[theta,pos2] == 0 and np.isfinite(corr_vel[theta,pos2]): #!= fill_value:
                                  v4.append(corr_vel[theta,pos2])
                              #temp.append(pos1)
                                  gc = 1
                                  gv = []
                                  rb = pos1+1
                                  while gc <=3 and rb <= int(initial_gate2)+2:
                                        if gate_flag[theta,rb] == 1:
                                           gv.append(corr_vel[theta,rb])
                                           gc = gc+1
                                        rb = rb+1
                                 
                                  k_un = np.rint((np.average(gv) - corr_vel[theta,pos2])/(2*v_n))
                                  if (np.isfinite(k_un)):      
                                      corr_vel[theta,pos2] = corr_vel[theta,pos2] + k_un*2*v_n
                                      gate_flag[theta,pos2] = 1 
        
                v_c = corr_vel
                #v_c = np.ma.masked_equal(v_c,fill_value)                       
                ## save the corrected radial velocity ##    
                np.savetxt("%s/%s/%s_%s_corr_vel_sweep_%02d.txt" %(dirpath1,mode,mode,basename,sweep),corr_vel)
                    
        else: ## If num_azim for the sweep is not equal to 360
            v_c = np.ones((360,num_bins)) * np.nan
            np.savetxt("%s/%s/%s_%s_corr_vel_sweep_%02d.txt" %(dirpath1,mode,mode,basename,sweep),v_c)

    return


tstart=dt.datetime.now() 

def mp_handler():
	p=multiprocessing.Pool(6)
	p.map(process_raw_file, sortedfiles)


if __name__=='__main__' :
	mp_handler()


print("Quality control took:",dt.datetime.now()-tstart)          
